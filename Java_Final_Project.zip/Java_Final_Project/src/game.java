import java.util.Random;


//게임의 진입점이 되는 부분
//게임 시작화면을 생성한다.
public class game {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Start start = new Start();
	}
}
